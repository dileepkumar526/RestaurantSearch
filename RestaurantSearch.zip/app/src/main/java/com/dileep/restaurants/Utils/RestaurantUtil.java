package com.dileep.restaurants.Utils;

public class RestaurantUtil {
    public static final String FILE_NAME = "Restaurants.json";
    public static final String KEY_RESTAURANT = "key_restaurant";
}

