package com.dileep.restaurants.Utils;

public class MenuUtil {
    public static final String FILE_NAME = "Menus.json";
    public static final String KEY_MENU = "key_menu";
}
